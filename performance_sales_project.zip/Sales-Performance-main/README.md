Performance-Sales

measuring the success of retail stores in terms of customer acquisition, customer retention, burn rate analysis, and trends by year and subcategory.